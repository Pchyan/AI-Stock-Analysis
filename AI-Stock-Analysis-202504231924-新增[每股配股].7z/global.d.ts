// 全局類型定義

interface Window {
  updateTradesAfterStockRemoval?: (symbol: string) => void;
}
